
<html>
<head>
<title>Add film</title>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Mr+Dafoe'>

    <link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="">
</head>
<body>
  <!--form to enter new film-->
<form action="addedfilm.php" method="post">
<center>
  <h1>Add a New film</h1>
  <p>Title:
  <input type="text" name="title" size="30" value="" />
  </p>
  <p>Year:
  <input type="text" name="year" size="30" value="" />
  </p>
  <p>genre:
  <input type="text" name="genre" size="30" value="" />
  </p>
  <p>
  <input type="submit" name="submit" value="Send" />
  </p>
</center>
</form>
</body>
</html>

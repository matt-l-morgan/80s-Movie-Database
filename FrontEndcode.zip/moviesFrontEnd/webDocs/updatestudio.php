<html>
<head>
<title>Update Studio</title>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Mr+Dafoe'>

    <link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="">
</head>
<body>
  <!--forum for updating a studio-->
<form action="updatedstudio.php" method="post">
<center>
  <h1>Update an existing studio</h1>
  <p>Studio Id:
  <input type="text" name="sid" size="30" value="" />
  </p>
  <p>Studio Name:
  <input type="text" name="name" size="30" value="" />
  </p>
  <p>Parent Company:
  <input type="text" name="company" size="30" value="" />
  </p>
  <p>City:
  <input type="text" name="city" size="30" value="" />
  </p>
  <p>Country:
  <input type="text" name="country" size="30" value="" />
  </p>
  <p>
  <input type="submit" name="submit" value="Send" />
  </p>
</center>
</form>
</body>
</html>

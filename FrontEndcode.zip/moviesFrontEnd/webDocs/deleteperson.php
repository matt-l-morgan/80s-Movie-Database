<html>
<head>
<title>Delete a person</title>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Mr+Dafoe'>

    <link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="">
</head>
<body>
  <!--form for adding a person-->
<form action="deletedperson.php" method="post">
<center>
  <h1>Delete a person</h1>
  <p>Person ID:
  <input type="text" name="pid" size="30" value="" />
  <input type="submit" name="submit" value="Send" />
  </p>
</center>
</form>
</body>
</html>

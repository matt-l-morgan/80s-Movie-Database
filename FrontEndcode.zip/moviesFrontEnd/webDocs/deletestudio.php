<html>
<head>
<title>Delete a studio</title>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Mr+Dafoe'>

    <link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="">
</head>
<body>
  <!--form for adding a studio-->
<form action="deletedstudio.php" method="post">
<center>
  <h1>Delete a studio</h1>
  <p>studio ID:
  <input type="text" name="sid" size="30" value="" />
  <input type="submit" name="submit" value="Send" />
  </p>
</center>
</form>
</body>
</html>

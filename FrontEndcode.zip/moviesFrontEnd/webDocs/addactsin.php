<html>
<head>
<title>Add "Acts in" relation</title>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Mr+Dafoe'>

  <link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="">
</head>
<body>
<!--form for adding an Acts-in relationship-->
<form action="addedactsin.php" method="post">
<center>
  <h1>Add a "Acts in" relationship</h1>
  <p>Person ID:
  <input type="text" name="personId" size="30" value="" />
  </p>
  <p>Film ID:
  <input type="text" name="filmId" size="30" value="" />
  </p>
  <p>
  <input type="submit" name="submit" value="Send" />
  </p>
</center>
</form>
</body>
</html>

<html>
<head>
<title>Delete a "directs" relationship</title>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Mr+Dafoe'>

    <link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="">
</head>
<body>
  <!--form for deleting an directs relationship-->
<form action="deleteddirects.php" method="post">
<center>
  <h1>Delete a "directs" relationship</h1>
  <p>Person ID:
  <input type="text" name="pid" size="30" value="" />
  <p>Film ID:
  <input type="text" name="fid" size="30" value="" />
  <input type="submit" name="submit" value="Send" />
  </p>
</center>
</form>
</body>
</html>

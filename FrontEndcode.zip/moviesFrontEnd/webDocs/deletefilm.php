<html>
<head>
<title>Delete a film</title>
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Mr+Dafoe'>

    <link rel="stylesheet" href="style.css">
<link rel="shortcut icon" href="">
</head>
<body>
  <!--form for deleting and film-->
<form action="deletedfilm.php" method="post">
<center>
  <h1>Delete a film</h1>
  <p>Film ID:
  <input type="text" name="fid" size="30" value="" />
  <input type="submit" name="submit" value="Send" />
  </p>
</center>
</form>
</body>
</html>
